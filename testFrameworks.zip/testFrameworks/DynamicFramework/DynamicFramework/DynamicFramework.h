//
//  DynamicFramework.h
//  DynamicFramework
//
//  Created by Zinets Victor on 6/1/16.
//  Copyright © 2016 Zinets Victor. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DynamicFramework.
FOUNDATION_EXPORT double DynamicFrameworkVersionNumber;

//! Project version string for DynamicFramework.
FOUNDATION_EXPORT const unsigned char DynamicFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like
#import <DynamicFramework/DynamicLib.h>


