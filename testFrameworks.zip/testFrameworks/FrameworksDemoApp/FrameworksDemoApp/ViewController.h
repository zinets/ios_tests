//
//  ViewController.h
//  FrameworksDemoApp
//
//  Created by Zinets Victor on 6/1/16.
//  Copyright © 2016 Zinets Victor. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

